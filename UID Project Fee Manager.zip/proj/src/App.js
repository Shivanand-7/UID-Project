import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header.js';
import Login from './components/Login.js';
import Dashboard from './components/Dashboard.js';
import FeePolicies from './components/FeePolicies.js';
import FAQs from './components/FAQs.js';
import Announcements from './components/Announcements.js';
import ContactInfo from './components/ContactInfo.js';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
        <Route path="/dashboard" element={<Dashboard />} /> 
          <Route path="/" element={<Login />} />
          <Route path="/fee" element={<FeePolicies />} />
          <Route path="/FAQs" element={<FAQs />} />
          <Route path="/Announcements" element={<Announcements />} />
          <Route path="/ContactInfo" element={<ContactInfo />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
