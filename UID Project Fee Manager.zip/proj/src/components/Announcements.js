import React from 'react';
import img3jpg from './img3jpg.jpg';

const Announcements = () => {
  return (
    <div style={{ padding: '20px' ,fontSize:'large' ,backgroundImage: `url(${img3jpg})`, backgroundSize:'cover',
    color:'white' ,
    textShadow:'-.5px -.5px 0 #000,  .5px -.5px 0 #000,-.5px  .5px 0 #000,.5px  .5px 0 #000'}}>
      <h2 style={{ marginBottom: '10px' }}>Announcements/Notices</h2>
        <h3>1. Upcoming Payment Deadlines:</h3>
        <p>- *Fall Semester Tuition Fees:* Due by September 15th.</p>
        <p>- *Spring Semester Tuition Fees:* Due by January 15th.</p>

        <h3>2. Policy Updates:</h3>
        <p>- Effective next semester, the late payment penalty for tuition fees will increase to 10% per week.</p>

        <h3>3. Special Notices:</h3>
        <p>- *New Payment Methods:* We now accept payments via PayPal and other major payment apps.</p>
        <p>- *Holiday Closure:* The finance office will be closed from December 24th to January 2nd. Please plan accordingly for any payment-related inquiries.</p>

        <h3>4. Fee Adjustment:</h3>
        <p>- Starting next academic year, lab fees will be increased by $50 to cover new equipment costs.</p>

        <p>For the latest updates, please check this page regularly.</p>
    </div>
  );
};

export default Announcements;
