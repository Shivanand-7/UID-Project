import React, { useState, useEffect } from 'react';
import './ClassManager.css';
import StudentManager from './StudentManager.js';

  const ClassManager = () => {
  const [classes, setClasses] = useState([]);
  const [newClassName, setNewClassName] = useState('');
  const [newFeePerSubject, setNewFeePerSubject] = useState('');
  const [isAddingClass, setIsAddingClass] = useState(false);
  const [selectedClass, setSelectedClass] = useState(null);
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const savedClasses = JSON.parse(localStorage.getItem('classes')) || [];
    setClasses(savedClasses);
  }, []);

  useEffect(() => {
    localStorage.setItem('classes', JSON.stringify(classes));
  }, [classes]);

  const addClass = () => {
    const newClass = {
      name: newClassName,
      id: Date.now(),
      feePerSubject: newFeePerSubject,
      students: [],
    };
    setClasses([...classes, newClass]);
    setNewClassName('');
    setNewFeePerSubject('');
    setIsAddingClass(false);
  };
  const handleClassSelect = (classItem) => {
    setSelectedClass(classItem);
    setShowPopup(true);
  };

  const deleteClass = (index) => {
    setClasses(classes.filter((_, i) => i !== index));
  };

  return (
    <div>
      <h2 style={{marginBottom:'20px',color:'white' ,textShadow:'-2px -2px 0 #000,  2px -2px 0 #000,-2px  2px 0 #000,2px  2px 0 #000'}}>MANAGE CLASSES</h2>
      {isAddingClass ? (
        <div>
          <div style={{margin: '10px', marginLeft:'100px',marginRight:'100px'}}>
          <input style={{backgroundColor: 'rgba(255, 255, 255, 0.5)',color:'black' }}
            type="text"
            placeholder="Class Name"
            value={newClassName}
            onChange={(e) => setNewClassName(e.target.value)}
            maxLength={50}
          /></div>
          <div style={{margin: '10px', marginLeft:'100px',marginRight:'100px'}}>
          <input style={{backgroundColor: 'rgba(255, 255, 255, 0.5)',color:'black'          }}
            type="text"
            placeholder="Fee Per Subject"
            value={newFeePerSubject}
            onChange={(e) => setNewFeePerSubject(e.target.value)}
          /></div>
          <button className="lineGap" onClick={addClass} >Add Class</button>
        </div>
      ) : (
        <button className="lineGap" onClick={() => setIsAddingClass(true)} style={{backgroundColor :'#a8b090'}}>Add Class</button>
      )}
      <ul>
      {classes.map((classItem, index) => (
        <div style={{ alignContent:'center',border: '2px solid black', backgroundColor: 'rgba(255, 255, 255, 0.3)', padding: '10px', margin: '10px', marginLeft:'400px',marginRight:'400px', borderRadius: '5px' }}>
        <li className="lineGap" key={index} onClick={() => handleClassSelect(classItem)}>
        <span style={{ fontWeight: 'bold', fontSize: '18px',textTransform: 'uppercase' }}>{classItem.name}</span>
         <span className="space"></span>                                      
          <button onClick={() => deleteClass(index)} style={{backgroundColor:'#d4a5a5',color:'#f8f4e3',textShadow:'-1px -1px 0 #000,  1px -1px 0 #000,-1px  1px 0 #000,1px  1px 0 #000'}}>Delete</button>
        </li>
        </div>
        
      ))}
    </ul>
    {showPopup && selectedClass && (
  <div className="popup">
    <div className="popup-content">
      <button style={{position: 'absolute' ,top: '0',right: '0', backgroundColor:'red',color:'white'}}onClick={() => setShowPopup(false)}>X</button>
      <StudentManager selectedClass={selectedClass} />
    </div>
  </div>
)}
    </div>
  );
};

export default ClassManager;
