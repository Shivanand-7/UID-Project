import React from 'react';
import img2 from './img2.jpg';

const ContactInfo = () => {
  return (
    <div style={{ padding: '20px',fontSize:'large',backgroundImage: `url(${img2})`,backgroundSize:'cover',color:'white' ,
    textShadow:'-.5px -.5px 0 #000,  .5px -.5px 0 #000,-.5px  .5px 0 #000,.5px  .5px 0 #000'}}>
      <h2 style={{ marginBottom: '10px' }}>Contact Information</h2>
        <p>For any questions or concerns regarding fees, please contact us using the following information:</p>

        <h3>Finance Office</h3>
-       <h3>Phone: +1 (123) 456-7890</h3>
-       <h3>Email: financeoffice@institution.edu</h3>
-       <h3>Office Hours: Monday to Friday, 9:00 AM - 5:00 PM</h3>

        <h3>Mailing Address:</h3>
        <p>Finance Office</p>
        <p>Institution Name</p>
        <p>123 College Avenue</p>
        <p>City, State, ZIP Code</p>

        <h3>Onsite Finance Office Location:</h3>
        <p>Finance Office is located in Building B, Room 205. See the campus map below for directions.</p>

    </div>
  );
};

export default ContactInfo;
