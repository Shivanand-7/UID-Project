import React, { useState } from 'react';
import ClassManager from './ClassManager.js';
import StudentManager from './StudentManager.js';
import './Dashboard.css';

const Dashboard = () => {
  const [selectedClass, setSelectedClass] = useState(null);
  

 
 
  return (
    <div className="dashboard">
      
      <ClassManager setSelectedClass={setSelectedClass} />
      {selectedClass && <StudentManager selectedClass={selectedClass} />}
    </div>
  );
};

export default Dashboard;
