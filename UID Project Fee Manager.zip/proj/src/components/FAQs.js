import React from 'react';
import img1 from './img1.jpg';

const FAQs = () => {
  return (
    <div className="FAQ" style={{ padding: '20px',fontSize:'large', backgroundImage: `url(${img1})`,backgroundSize:'cover'}}>
      <h2 style={{ marginBottom: '10px' }}>Frequently Asked Questions</h2>
        <h3>Q1: When are tuition fees due?</h3>
        <p>A: Tuition fees are due at the beginning of each semester.</p>
        <p>A Specific dates will be announced on the homepage.</p>

        <h3>Q2: What payment methods are accepted?</h3>
        <p>A: We accept online payments via credit/debit cards, bank transfers,</p>
        <p>and payment apps. Check the home page for detailed payment instructions.</p>

        <h3>Q3: Can I pay my fees in installments?</h3>
        <p>A: Yes, installment plans are available.</p> 
        <p>Please contact the finance office for more information.</p>

        <h3>Q4: What should I do if I can't pay my fees on time?</h3>
        <p>A: Contact the finance office as soon as possible to discuss possible solutions or payment plans.</p>

        <h3>Q5: How can I get a refund?</h3>
        <p>A : Refunds are processed according to our refund policy.</p> 
        <p>You must apply for a refund within the first two weeks of the semester.</p> 
        <p>No refunds are issued after this period.</p>

    </div>
  );
};

export default FAQs;
