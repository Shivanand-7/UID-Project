import React from 'react';
import img3jpg from './img3jpg.jpg';

const FeePolicies = () => {
  return (
    <div className="fee" style={{ padding: '20px',fontSize:'large',
    backgroundImage: `url(${img3jpg})`, backgroundSize:'cover',color:'white',textShadow:'-.5px -.5px 0 #000,  .5px -.5px 0 #000,-.5px  .5px 0 #000,.5px  .5px 0 #000'}}>
      <h2 style={{ marginBottom: '10px' }}>Fee Policies</h2>
      <p>Welcome to the Fee Policies page. Here you will find detailed information on our fee structure and policies.</p>
      <h3 style={{ marginTop: '20px' }}>Tuition Fees</h3>
      <p><strong>Due Dates:</strong> Tuition fees are due at the beginning of each semester. The exact dates will be communicated via official notices.</p>
      <p><strong>Late Payment Penalties:</strong> A late fee of 5% of the overdue amount will be applied for each week past the due date.</p>
      <p><strong>Refund Policy:</strong> Tuition fees are refundable within the first two weeks of the semester. No refunds will be processed after this period.</p>

      {/* Add other fee details */}
    </div>
  );
};

export default FeePolicies;
