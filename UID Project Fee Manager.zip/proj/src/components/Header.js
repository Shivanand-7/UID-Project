import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => {
  return (
    <header id="header" className="header-section" style={{fontSize:'15px'}}>
      <div className="container">
        <div className="navbar navbar-expand-lg navbar-light bg-light">
          <Link to="/" className="navbar-brand">
            <img src={`${process.env.PUBLIC_URL}/assets/img/logo.png`} alt="logo" />
          </Link>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item">
                
                <Link to="/dashboard" className="nav-link">HOME</Link>
              </li>
              <li className="nav-item">
                <Link to="/fee" className="nav-link">Fee Policies</Link>
              </li>
              <li className="nav-item">
                <Link to="/FAQs" className="nav-link">FAQ'S</Link>
              </li>
              <li className="nav-item">
                <Link to="/Announcements" className="nav-link">Announcements</Link>
              </li>
              <li className="nav-item">
                <Link to="/ContactInfo" className="nav-link">Contact</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
