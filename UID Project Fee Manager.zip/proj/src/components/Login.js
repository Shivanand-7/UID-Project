import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:3000/Login', {
        username,
        password,
      });

      if (response.status === 200) {
        navigate('/Dashboard');
      }
    } catch (error) {
      alert('Invalid credentials');
    }
  };

  return (
    <div className="container mt-5" style={{fontSize:'15px'}}>
    <div className="row justify-content-center">
      <div className="col-md-6">
        <div className="card">
          <div className="card-body">
            <h2 className="card-title text-center" style={{color:'white' ,
    textShadow:'-.5px -.5px 0 #000,  .5px -.5px 0 #000,-.5px  .5px 0 #000,.5px  .5px 0 #000'}}>Login</h2>
            <div className="form-group" style={{fontSize:'15px'}}>
              <label htmlFor="username">Username</label>
              <input
                type="text"
                className="form-control"
                id="username"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                className="form-control"
                id="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <button onClick={handleLogin} className="btn btn-primary btn-block">
              Login
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
);
};

export default Login;