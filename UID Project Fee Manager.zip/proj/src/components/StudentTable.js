import React from 'react';

const StudentTable = ({ students, updateStudentStatus, deleteStudent,feePerSubject }) => {
  const pendingStudents = students.filter(student => student.feeStatus === 'pending').length;
  const receivedStudents = students.filter(student => student.feeStatus === 'received').length;

  return (
    <div>
      <h3 style={{margin:'10px'}}>STUDENTS</h3>
      <div style={{margin: '10px'}}></div>
      <p>Pending: {pendingStudents} | Received: {receivedStudents}</p>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Subjects</th>
            <th>Total Fees</th>
            <th>Contact</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student, index) => (
            <tr key={index} className={student.feeStatus === 'pending' ? 'pending' : 'received'}>
              <td>{student.name}</td>
              <td>{student.noOfSubjects}</td>
              <td>{student.noOfSubjects * feePerSubject}</td>
              <td>{student.contactNumber}</td>
              <td>{student.feeStatus}</td>
              <td>
                <button onClick={() => updateStudentStatus(index, 'received')}>Receive Fee</button>
                <button onClick={() => updateStudentStatus(index, 'pending')}>Reset Fee</button>
                <button onClick={() => deleteStudent(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StudentTable;
