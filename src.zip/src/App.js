import React, { useState, useEffect } from 'react';
import ClassManagement from './components/ClassManagement';
import StudentManagement from './components/StudentManagement';

const App = () => {
    const [classes, setClasses] = useState([]);
    const [selectedClass, setSelectedClass] = useState(null);

    useEffect(() => {
        const storedClasses = JSON.parse(localStorage.getItem('classesNames')) || [];
        setClasses(storedClasses);
        if (storedClasses.length > 0) {
            setSelectedClass(storedClasses[0].name);
        }
    }, []);

    const addClass = (className, feePerSubject) => {
        const newClass = { name: className, fee: feePerSubject };
        const updatedClasses = [...classes, newClass];
        setClasses(updatedClasses);
        localStorage.setItem('classesNames', JSON.stringify(updatedClasses));
        setSelectedClass(className);
    };

    const deleteClass = (className) => {
        const updatedClasses = classes.filter(cls => cls.name !== className);
        setClasses(updatedClasses);
        localStorage.setItem('classesNames', JSON.stringify(updatedClasses));
        localStorage.removeItem(className);
        if (updatedClasses.length > 0) {
            setSelectedClass(updatedClasses[0].name);
        } else {
            setSelectedClass(null);
        }
    };

    return (
        <div className="container my-5">
            <h1 className="text-center">Welcome to</h1>
            <h1 className="text-center text-cadetblue font-weight-bold">Fee Management System.</h1>
            <hr />
            <p className="text-center font-italic text-shadow">"<span className="font-weight-bold text-cadetblue">Teachers</span> can open the door, but you must enter it yourself."</p>
            <hr />
            <ClassManagement
                classes={classes}
                addClass={addClass}
                deleteClass={deleteClass}
                selectedClass={selectedClass}
                setSelectedClass={setSelectedClass}
            />
            {selectedClass && (
                <StudentManagement
                    selectedClass={selectedClass}
                />
            )}
        </div>
    );
};

export default App;
