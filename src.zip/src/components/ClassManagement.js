import React, { useState } from 'react';
import Modal from './Modal';

const ClassManagement = ({ classes, addClass, deleteClass, selectedClass, setSelectedClass }) => {
    const [showAddClassModal, setShowAddClassModal] = useState(false);

    return (
        <div className="d-flex justify-content-center mb-3">
            <button className="btn btn-primary mx-2" onClick={() => setShowAddClassModal(true)}>
                Add a Class
            </button>
            <button className="btn btn-danger mx-2" onClick={() => deleteClass(selectedClass)}>
                Delete this Class
            </button>
            <select
                className="form-control mx-2"
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
            >
                {classes.map(cls => (
                    <option key={cls.name} value={cls.name}>
                        {cls.name}
                    </option>
                ))}
            </select>
            {showAddClassModal && (
                <Modal
                    onClose={() => setShowAddClassModal(false)}
                    onSave={addClass}
                />
            )}
        </div>
    );
};

export default ClassManagement;
