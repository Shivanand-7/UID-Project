import React, { useState } from 'react';

const ClassManager = ({ setSelectedClass }) => {
  const [classes, setClasses] = useState([]);
  const [newClassName, setNewClassName] = useState('');
  const [newFeePerSubject, setNewFeePerSubject] = useState('');
  const [isAddingClass, setIsAddingClass] = useState(false);

  const addClass = () => {
    const newClass = {
      name: newClassName,
      feePerSubject: newFeePerSubject,
      students: [],
    };
    setClasses([...classes, newClass]);
    setNewClassName('');
    setNewFeePerSubject('');
    setIsAddingClass(false);
  };

  const deleteClass = (index) => {
    setClasses(classes.filter((_, i) => i !== index));
  };

  return (
    <div>
      <h2>Manage Classes</h2>
      {isAddingClass ? (
        <div>
          <input
            type="text"
            placeholder="Class Name"
            value={newClassName}
            onChange={(e) => setNewClassName(e.target.value)}
          />
          <input
            type="text"
            placeholder="Fee Per Subject"
            value={newFeePerSubject}
            onChange={(e) => setNewFeePerSubject(e.target.value)}
          />
          <button onClick={addClass}>Add Class</button>
        </div>
      ) : (
        <button onClick={() => setIsAddingClass(true)}>Add Class</button>
      )}
      <ul>
        {classes.map((classItem, index) => (
          <li key={index} onClick={() => setSelectedClass(classItem)}>
            {classItem.name}
            <button onClick={() => deleteClass(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ClassManager;
