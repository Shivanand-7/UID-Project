import React from 'react';

const Footer = () => (
    <footer className="bg-dark py-3" id="footer" style={{ marginLeft: '15px' }}>
        <p className="text-center mb-0">
            Developed By: &copy;CSE-D UID <span className="text-cadetblue">&nbsp;</span>
        </p>
    </footer>
);

export default Footer;
