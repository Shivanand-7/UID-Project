import React from 'react';

const Header = () => (
    <div>
        <h1 className="text-center">Welcome to</h1>
        <h1 className="text-center text-cadetblue font-weight-bold">Fee Management System</h1>
        <hr />
        <p className="text-center font-italic text-shadow">
            "<span className="font-weight-bold text-cadetblue">Teachers</span> can open the door, but you must enter it yourself."
        </p>
        <hr />
    </div>
);
export default Header;