import React, { useState } from 'react';

const Modal = ({ onClose, onSave }) => {
    const [name, setName] = useState('');
    const [feePerSubject, setFeePerSubject] = useState('');
    const [noOfSub, setNoOfSub] = useState('');
    const [contact, setContact] = useState('');

    const handleSave = () => {
        if (feePerSubject) {
            onSave(name, feePerSubject);
        } else {
        onSave(name, noOfSub, contact);
        }
        onClose();
        };
        return (
            <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0, 0, 0, 0.5)' }}>
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">{feePerSubject ? 'Add a Class' : 'Add a Student'}</h5>
                            <button type="button" className="btn-close" aria-label="Close" onClick={onClose}></button>
                        </div>
                        <div className="modal-body">
                            <form>
                                <div className="mb-3">
                                    <label htmlFor="name" className="form-label">{feePerSubject ? 'Class Name' : 'Student Name'}</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="name"
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                    />
                                </div>
                                {feePerSubject ? (
                                    <div className="mb-3">
                                        <label htmlFor="fee" className="form-label">Fee per Subject</label>
                                        <input
                                            type="number"
                                            className="form-control"
                                            id="fee"
                                            value={feePerSubject}
                                            onChange={(e) => setFeePerSubject(e.target.value)}
                                        />
                                    </div>
                                ) : (
                                    <>
                                        <div className="mb-3">
                                            <label htmlFor="noOfSub" className="form-label">Number of Subjects</label>
                                            <input
                                                type="number"
                                                className="form-control"
                                                id="noOfSub"
                                                value={noOfSub}
                                                onChange={(e) => setNoOfSub(e.target.value)}
                                            />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="contact" className="form-label">Contact Number</label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="contact"
                                                value={contact}
                                                onChange={(e) => setContact(e.target.value)}
                                            />
                                        </div>
                                    </>
                                )}
                            </form>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" onClick={onClose}>Close</button>
                            <button type="button" className="btn btn-primary" onClick={handleSave}>Save</button>
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    export default Modal;