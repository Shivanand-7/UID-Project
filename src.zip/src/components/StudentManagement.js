import React, { useState, useEffect } from 'react';

const StudentManagement = ({ selectedClass }) => {
    const [students, setStudents] = useState([]);
    const [showAddStudentModal, setShowAddStudentModal] = useState(false);
    const [newStudentName, setNewStudentName] = useState('');
    const [newStudentNoOfSub, setNewStudentNoOfSub] = useState('');
    const [newStudentContact, setNewStudentContact] = useState('');

    useEffect(() => {
        const storedStudents = JSON.parse(localStorage.getItem(selectedClass)) || [];
        setStudents(storedStudents);
    }, [selectedClass]);

    const addStudent = () => {
        const feePerSubject = JSON.parse(localStorage.getItem('classesNames')).find(cls => cls.name === selectedClass).fee;
        const newStudent = {
            name: newStudentName,
            noOfSub: newStudentNoOfSub,
            contact: newStudentContact,
            condition: 'Pending',
            fee: feePerSubject * newStudentNoOfSub,
        };
        const updatedStudents = [...students, newStudent];
        setStudents(updatedStudents);
        localStorage.setItem(selectedClass, JSON.stringify(updatedStudents));
        setShowAddStudentModal(false);
    };

    const deleteStudent = (index) => {
        const updatedStudents = students.filter((_, i) => i !== index);
        setStudents(updatedStudents);
        localStorage.setItem(selectedClass, JSON.stringify(updatedStudents));
    };

    const receiveFee = (index) => {
        const updatedStudents = students.map((student, i) => i === index ? { ...student, condition: 'Received' } : student);
        setStudents(updatedStudents);
        localStorage.setItem(selectedClass, JSON.stringify(updatedStudents));
    };

    const resetFeeStatus = (index) => {
        const updatedStudents = students.map((student, i) => i === index ? { ...student, condition: 'Pending' } : student);
        setStudents(updatedStudents);
        localStorage.setItem(selectedClass, JSON.stringify(updatedStudents));
    };

    const resetAllConditions = () => {
        const updatedStudents = students.map(student => ({ ...student, condition: 'Pending' }));
        setStudents(updatedStudents);
        localStorage.setItem(selectedClass, JSON.stringify(updatedStudents));
    };

    const removeAllData = () => {
        localStorage.removeItem(selectedClass);
        setStudents([]);
    };

    const { paidCount, pendingCount } = students.reduce(
        (acc, student) => {
            if (student.condition === 'Received') acc.paidCount++;
            else acc.pendingCount++;
            return acc;
        },
        { paidCount: 0, pendingCount: 0 }
    );

    return (
        <div className="container">
            <div className="d-flex justify-content-center mb-3">
                <button className="btn btn-success mx-2" onClick={() => setShowAddStudentModal(true)}>
                    Add a Student
                </button>
                <button className="btn btn-warning mx-2" onClick={resetAllConditions}>
                    Reset All Conditions
                </button>
                <button className="btn btn-danger mx-2" onClick={removeAllData}>
                    Erase All Data
                </button>
            </div>
            <div className="table-responsive">
                <table className="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Student Name</th>
                            <th>Condition</th>
                            <th>NO. of subjects</th>
                            <th>Total Fee</th>
                            <th>Contact NO.</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {students.map((student, index) => (
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{student.name}</td>
                                <td>{student.condition}</td>
                                <td>{student.noOfSub}</td>
                                <td>{student.fee}</td>
                                <td>{student.contact}</td>
                                <td>
                                    <button className="btn bg-green" onClick={() => receiveFee(index)}>Receive</button>
                                    <button className="btn" onClick={() => resetFeeStatus(index)}>Reset Fee</button>
                                    <br />
                                    <button className="btn bg-red" onClick={() => deleteStudent(index)}>Delete Student</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div id="fee-status">
                Paid: {paidCount} | Pending: {pendingCount}
            </div>

            {showAddStudentModal && (
                <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0, 0, 0, 0.5)' }}>
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Add a Student</h5>
                                <button type="button" className="btn-close" aria-label="Close" onClick={() => setShowAddStudentModal(false)}></button>
                            </div>
                            <div className="modal-body">
                                <form>
                                    <div className="mb-3">
                                        <label htmlFor="studentName" className="form-label">Student Name</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="studentName"
                                            value={newStudentName}
                                            onChange={(e) => setNewStudentName(e.target.value)}
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="noOfSub" className="form-label">Number of Subjects</label>
                                        <input
                                            type="number"
                                            className="form-control"
                                            id="noOfSub"
                                            value={newStudentNoOfSub}
                                            onChange={(e) => setNewStudentNoOfSub(e.target.value)}
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="contact" className="form-label">Contact Number</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="contact"
                                            value={newStudentContact}
                                            onChange={(e) => setNewStudentContact(e.target.value)}
                                        />
                                    </div>
                                </form>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" onClick={() => setShowAddStudentModal(false)}>Close</button>
                                <button type="button" className="btn btn-primary" onClick={addStudent}>Save</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default StudentManagement;
