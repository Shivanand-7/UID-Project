import React, { useState } from 'react';
import StudentTable from './StudentTable.js';

const StudentManager = ({ selectedClass }) => {
  const [students, setStudents] = useState(selectedClass.students || []);
  const [studentName, setStudentName] = useState('');
  const [noOfSubjects, setNoOfSubjects] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [isAddingStudent, setIsAddingStudent] = useState(false);

  const addStudent = () => {
    if (studentName && noOfSubjects && contactNumber) {
      const newStudent = {
        name: studentName,
        noOfSubjects: parseInt(noOfSubjects, 10),
        contactNumber: contactNumber,
        feeStatus: 'pending',
      };
      const updatedStudents = [...students, newStudent];
      setStudents(updatedStudents);
      selectedClass.students = updatedStudents;
      setStudentName('');
      setNoOfSubjects('');
      setContactNumber('');
      setIsAddingStudent(false);
    }
  };

  const updateStudentStatus = (index, status) => {
    const updatedStudents = students.map((student, i) =>
      i === index ? { ...student, feeStatus: status } : student
    );
    setStudents(updatedStudents);
    selectedClass.students = updatedStudents;
  };

  const deleteStudent = (index) => {
    const updatedStudents = students.filter((_, i) => i !== index);
    setStudents(updatedStudents);
    selectedClass.students = updatedStudents;
  };

  return (
    <div>
      <h2>Manage Students for {selectedClass.name}</h2>
      {isAddingStudent ? (
        <div>
          <input
            type="text"
            placeholder="Student Name"
            value={studentName}
            onChange={(e) => setStudentName(e.target.value)}
          />
          <input
            type="number"
            placeholder="Number of Subjects"
            value={noOfSubjects}
            onChange={(e) => setNoOfSubjects(e.target.value)}
          />
          <input
            type="text"
            placeholder="Contact Number"
            value={contactNumber}
            onChange={(e) => setContactNumber(e.target.value)}
          />
          <button onClick={addStudent}>Add Student</button>
        </div>
      ) : (
        <button onClick={() => setIsAddingStudent(true)}>Add Student</button>
      )}
      <StudentTable
        students={students}
        updateStudentStatus={updateStudentStatus}
        deleteStudent={deleteStudent}
        feePerSubject={selectedClass.feePerSubject}
        selectedClass={selectedClass}
      />
    </div>
  );
};

export default StudentManager;