import React from 'react';

const Table = ({ students }) => (
    <div className="table-responsive">
        <table className="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Sr No.</th>
                    <th>Student Name</th>
                    <th>Condition</th>
                    <th>NO. of subjects</th>
                    <th>Total Fee</th>
                    <th>Contact NO.</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {students.map((student, index) => (
                    <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{student.name}</td>
                        <td>{student.condition}</td>
                        <td>{student.noOfSub}</td>
                        <td>{student.fee}</td>
                        <td>{student.contact}</td>
                        <td>
                            <button className="btn btn-sm btn-primary">Edit</button>
                            <button className="btn btn-sm btn-danger">Delete</button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
);

export default Table;
